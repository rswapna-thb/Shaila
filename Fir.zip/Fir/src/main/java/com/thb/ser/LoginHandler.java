package com.thb.ser;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;

public class LoginHandler {
 
public ArrayList<UserVO> getAllUsers(Connection connection) throws Exception {
ArrayList<UserVO> userList = new ArrayList<UserVO>();
try {

PreparedStatement ps = (PreparedStatement) connection
.prepareStatement("SELECT * FROM userdetails");

ResultSet rs = ps.executeQuery();
while (rs.next()) {
UserVO uservo = new UserVO();
uservo.setUsername(rs.getString("name"));
uservo.setPassword(rs.getString("password"));
userList.add(uservo);
}
return userList;
} catch (Exception e) {
throw e;
}
}
 
}