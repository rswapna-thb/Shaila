package com.thb.ser;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class LoginServiceTest {
	LoginService ls;
	@Before
	public void setUp() throws Exception {
		ls =new LoginService();
	}



	@Test
	public void testGetAllUsersList() {
		String str1="john";
		String str2="gfh";
		assertEquals("Login Succesfull" , ls.getAllUsersList(str1, str2));
	}
	@After
	public void tearDown() throws Exception {
	}


}
